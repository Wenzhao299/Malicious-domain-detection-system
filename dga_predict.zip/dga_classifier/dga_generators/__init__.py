__all__ = ['banjori', 'corebot', 'cryptolocker', 'dircrypt', 'kraken',
		   'lockyv2', 'pykspa', 'qakbot', 'ramdo', 'ramnit', 'simda']